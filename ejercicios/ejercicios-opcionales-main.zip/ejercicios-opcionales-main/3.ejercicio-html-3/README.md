# Tablas

Edita el fichero `index.html` para que muestre una tabla como la de esta imagen:

![Estructura HTML](./tabla.png)

El HTML resultante debe ser validado por el [validador de HTML de la W3](https://validator.w3.org/#validate_by_input) y no dar ningún error.
