# Creación de un layout responsive

Edita el fichero `index.html` para que muestre un curriculum con el siguiente aspecto

![CV](./cv.jpg)

El HTML y CSS resultantes deben ser validados por los validadores de la W3 y no dar ningún error.

[Validador de HTML de la W3](https://validator.w3.org/#validate_by_input)
[Validador de CSS de la W3](https://jigsaw.w3.org/css-validator/#validate_by_input)
