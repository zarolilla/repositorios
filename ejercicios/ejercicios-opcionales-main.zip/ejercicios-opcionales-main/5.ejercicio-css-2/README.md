Agrega un fichero css al "ejercicio-html-2". Maqueta el formulario para que tenga un aspecto como el de esta imagen. Para practicar selectores, intenta no seleccionar elementos por clase o id en tu fichero css.

![Aspecto formulario](./formulario.png)
