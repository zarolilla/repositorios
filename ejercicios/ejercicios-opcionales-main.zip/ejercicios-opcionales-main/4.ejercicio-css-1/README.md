Usa los selectores indicados para darle estilo a los elementos del html:

- Selecciona el "li" cuyo atributo "data-name" sea igual a "hack" y subráyalo de rojo.

- Selecciona el "li" segundo hijo de "ul" y haz que tenga un fondo amarillo al pasar el ratón por encima.

- Agrega un emoji después del "li" con clase "emoji".

- Selecciona el "li" último hijo de "ul" y haz que su primera letra sea de color naranja.

- Haz que el link tenga color rojo cuando esté sin visitar, y verde cuando esté visitado.
